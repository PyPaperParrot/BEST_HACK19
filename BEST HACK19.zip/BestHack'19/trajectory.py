import numpy as np
discharge_data = np.loadtxt("discharge_coordinates.txt", delimiter=' ', dtype=np.float)
data = np.loadtxt("trajectory.txt", delimiter=' ', dtype=np.float)

discharge_data = discharge_data.reshape(len(discharge_data), 2)[:,np.array([True,True])]
data = data.reshape(len(data), 5)[:,np.array([False, False, True, True, True])]
dis_y_len = len(discharge_data)

data = np.transpose(data)
discharge_data= np.transpose(discharge_data)

height = data[2][0]

dis_y = []
heigt = data[2][0]
for i in range(dis_y_len):
    dis_y.append(heigt)
dis_y = np.array(dis_y)


import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d 
# координаты точек
N = np.linspace(0,10,50)
x = data[0]
y = data[2]
z = data[1]


dis_x = discharge_data[0]

dis_z = discharge_data[1]

# построение и отображение графика
plt.gca(projection='3d')   # указываем тип
plt.xlabel('X')
plt.ylabel('Z')
plt.plot(x, z, y)
plt.plot(dis_x, dis_z, dis_y)
plt.show()



