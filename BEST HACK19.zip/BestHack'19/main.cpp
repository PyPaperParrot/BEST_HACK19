#define _USE_MATH_DEFINES
#include <iostream>
#include <vector>
#include <map>
#include <math.h>
#include <utility>
#include <iterator>
#include <fstream>
#include <ctime>
#include <thread>

const double g = 9.81;

void replacePath(std::vector <double> &coordinates,
	double coordinatesFinal) { //������������ ������� ���������� ����� ������-������� �������� �����
	int size = coordinates.size();
	for (int i = 0; i < size; i++) {
		coordinates[i] -= coordinatesFinal;
	}
	return;
}

std::vector <std::pair <double, double>> searchTimeSector(std::map <double, double> W,
	std::vector <double> y, const double h) { //��������� �����, �� ������� ���� ��������� ������ � ������ ������ ������� ������
	std::map <double, double> ::reverse_iterator itrStart = W.rbegin();
	std::map <double, double> ::reverse_iterator itrEnd = --W.rend();
	std::map <double, double> ::iterator itrY1, itrY2;
	std::vector <std::pair <double, double>> time;
	double stpH, currentH = h;
	for (std::map <double, double> ::reverse_iterator it = itrStart; it != itrEnd; ++it) {
		stpH = it->first - (++it)->first;
		--it;
		int j1 = 0;
		while (y[j1] > currentH) {
			j1++;
		}
		int j2 = j1;
		if (currentH - stpH > 0) {
			while (y[j2] > (currentH - stpH)) {
				j2++;
			}
		}
		else {
			j2 = y.size();
		}
		time.push_back(std::pair <double, double>(currentH - stpH, j2 - j1));
		if (currentH == 0 || (currentH - stpH) <= 0) {
			break;
		}
		currentH -= stpH;
	}
	return time;
}

std::pair <double, double> interpolateForce(std::map <double, double> aeroForce,
	const double speed) { //������� ��� ������������ ���������������� ���� � ������� ������ �������
	std::map <double, double> ::iterator itr = aeroForce.lower_bound(speed);
	double y1 = (itr)->second;
	double x1 = (itr)->first;
	double y2 = (++itr)->second;
	double x2 = (itr)->first;
	double k = (y2 - y1) / (x2 - x1);
	double b = (x2*y1 - x1 * y2) / (x2 - x1);
	return std::pair <double, double>(k, b);
}

std::vector<double> computeYCoordEulerMethod(const double m, const double dt,
	std::map <double, double> aeroForce, double h,
	std::vector<double> &ySpeed) {//���������� ���������� Y ������� ������
	std::vector <double> y;
	double a, speed = 0;
	std::map <double, double> ::iterator itr = ++aeroForce.begin();
	std::pair <double, double> lineForce;
	while (h > 0)
	{
		y.push_back(h);
		ySpeed.push_back(speed);
		if (abs(speed) > itr->first) {
			lineForce = interpolateForce(aeroForce, (abs(speed)));
			itr++;
		}
		a = (-g * m + lineForce.first*abs(speed) + lineForce.second) / m;
		h += speed * dt + a * dt*dt / 2;
		speed = speed + a * dt;
	}
	return (y);
}

void computeYCoordRKMethod(const double m, const double dt, std::map <double, double> aeroForce,
	double h, std::vector<double> &ySpeed,
	std::vector<double> &result) {//���������� ���������� Y ������� �����-�����
	std::vector <double> y;
	double a;
	double speed = 0, speedCorrection = 0;
	std::map <double, double> ::iterator itr = ++aeroForce.begin();
	std::pair <double, double> lineForce;
	while (h > 0)
	{
		y.push_back(h);
		ySpeed.push_back(speed);
		if (abs(speed) > itr->first) {
			lineForce = interpolateForce(aeroForce, abs(speed));
			itr++;
		}
		a = (-g * m + lineForce.first*abs(speed) + lineForce.second) / m;
		h += speed * dt + a * dt*dt / 2;
		speedCorrection = speed + a * dt;
		speed = speed + dt * (((-g * m + lineForce.first*abs(speed) + lineForce.second) / m + (-g * m + lineForce.first*abs(speedCorrection) + lineForce.second) / m) / 2);
	}
	result = y;
}

void computeError(const double m, const double dt, std::map <double, double> aeroForce,
	double h) { //��������� ����������� �������� �����, ���� 2 ������� ��������
	std::vector<double> y_speed;
	std::vector <double> y1;
	computeYCoordRKMethod(m, dt, aeroForce, h, y_speed, y1);
	std::vector <double> y2;
	computeYCoordRKMethod(m, dt * 2, aeroForce, h, y_speed, y2);
	if (y1.size() % 2 == 0) {
		std::cout << "Computational error: " << abs(y1[y1.size() - 1] - y2[(y1.size() - 1) / 2]) / 3 << std::endl;
	}
	else {
		double _pow = pow(2, y1.size() - 1);
		std::cout << "Computational error: " << abs(y1[y1.size() - 2] - y2[(y1.size() - 2) / 2]) / 3 << std::endl;
	}
	return;
}

void computeCoordinatesEulerMethod(const double m, const double dt, std::map <double, double> Wx,
	std::map <double, double> aeroForce, double xSpeed,
	std::vector <double> y, std::vector <std::pair<double, double>> timeSector,
	std::vector <double> &coordSpeed, std::vector <double> &result) { //���������� ��������� X � Z ������� ������
	std::vector <double> x;
	double aBody, currentX = 0, aWind;
	std::map <double, double> ::iterator itr = ++aeroForce.begin();
	int y_size = y.size();
	std::pair <double, double> lineForce;
	for (int i = 0; i < y_size; i++)
	{
		x.push_back(currentX);
		coordSpeed.push_back(xSpeed);
		if (abs(xSpeed) > itr->first) {
			lineForce = interpolateForce(aeroForce, (abs(xSpeed)));
			itr++;
		}
		std::map <double, double> ::iterator itr_Wx = Wx.lower_bound(y[i]);
		std::vector <std::pair<double, double>> ::iterator itrTimeSector = timeSector.begin();

		int k = 0;
		for (int j = 0; j<y_size, timeSector[j].first > y[i]; j++) {
			k++;
		}
		aWind = (-itr_Wx->second + (--itr_Wx)->second) / (dt*timeSector[k].second);
		if (xSpeed > 0) {
			aBody = (aWind*m - (lineForce.first*abs(xSpeed) + lineForce.second)) / m;
		}
		else {
			aBody = (aWind*m + (lineForce.first*abs(xSpeed) + lineForce.second)) / m;
		}
		currentX += xSpeed * dt + aBody * dt*dt / 2;
		xSpeed = xSpeed + aBody * dt;
	}
	result = x;
}

void computeCoordinatesRKMethod(const double m, const double dt, std::map <double, double> Wx,
	std::map <double, double> aeroForce, double xSpeed,
	std::vector <double> y, std::vector <std::pair<double, double>> timeSector,
	std::vector <double> &coordSpeed, std::vector <double> &result) { //���������� ��������� X � Z ������� �����-�����
	std::vector <double> x;
	double aBody, currentX = 0, aWind, xSpeedCorrection = xSpeed;
	std::map <double, double> ::iterator itr = ++aeroForce.begin();
	int y_size = y.size();
	std::pair <double, double> lineForce;
	for (int i = 0; i < y_size; i++)
	{
		x.push_back(currentX);
		coordSpeed.push_back(xSpeed);
		if (abs(xSpeed) > itr->first) {
			lineForce = interpolateForce(aeroForce, (abs(xSpeed)));
			itr++;
		}
		std::map <double, double> ::iterator itr_Wx = Wx.lower_bound(y[i]);

		int k = 0;
		for (int j = 0; j<y_size, timeSector[j].first > y[i]; j++) {
			k++;
		}
		aWind = (-itr_Wx->second + (--itr_Wx)->second) / (dt*timeSector[k].second);
		if (xSpeed > 0) {
			aBody = (aWind*m - (lineForce.first*xSpeed + lineForce.second)) / m;
		}
		else {
			aBody = (aWind*m + (lineForce.first*abs(xSpeed) + lineForce.second)) / m;
		}
		currentX += xSpeed * dt + aBody * dt*dt / 2;
		xSpeedCorrection = xSpeed + aBody * dt;
		xSpeed = xSpeed + dt * (aBody + (aWind*m - (lineForce.first*xSpeedCorrection + lineForce.second)) / m) / 2;

	}
	result = x;
}

void read_F_csv(std::map<double, double> &F_map, std::string file_name) {
	std::ifstream f(file_name);
	char dummy;
	float a, b;
	while (f >> a >> dummy >> b)
	{
		F_map[a] = b;
	}
	f.close();
	return;
}

void read_Wind_csv(std::map<double, double> &X_map, std::map<double, double> &Z_map, std::string file_name) {
	std::ifstream f(file_name);
	char dummy1, dummy2;
	float Y, Wx, Wz;
	while (f >> Y >> dummy1 >> Wx >> dummy2 >> Wz)
	{
		X_map[Y] = Wx;
		Z_map[Y] = Wz;
	}
	f.close();
	return;
}

void CSV_output(std::map<float, float> F_map) {
	for (auto it = F_map.begin(); it != F_map.end(); ++it)
	{
		std::cout << (*it).first << " : " << (*it).second << std::endl;
	}
	system("pause");
	system("cls");
}

void writeFile(const std::vector<double> vec, std::string file_name) {
	std::ofstream out;
	out.open(file_name);
	if (out.is_open())
	{
		std::copy(vec.begin(), vec.end(), std::ostream_iterator<double>(out, "\n"));
	}
	out.close();
	return;
}

int main() {
	setlocale(0, "russian");
	std::cout.precision(10);
	double dt = 0.01;
	double h;
	double m;
	double startSpeed;
	bool key = true;
	while (key == true) {
		std::cout << "Enter cargo dump height. The height must not exceed 1400 meters." << std::endl;
		std::cin >> h;
		std::cout << "Enter cargo weight." << std::endl;
		std::cin >> m;
		std::cout << "Enter initial velocity. It must not exceed 250 km/h." << std::endl;
		std::cin >> startSpeed;
		if (h > 1400 || h < 0 || m < 0 || startSpeed < 0 || startSpeed>250) {
			std::cout << "Nice try :) Data entered incorrectly. Please try again." << std::endl;
		}
		else {
			key = false;
		}
	}
	
	unsigned int start_time = clock();
	
	std::map <double, double> aeroForce, Wx, Wz;
	read_F_csv(aeroForce, "F.csv");
	read_Wind_csv(Wx, Wz, "Wind.csv");
	std::vector <double> x, z;
	std::vector <double>  y_speed, x_speed, z_speed;
	std::vector <double> y;
	computeYCoordRKMethod(m, dt, aeroForce, h, y_speed, y);
	int sizeOfcoordinates = y.size();

	std::vector <std::pair<double, double>> time = searchTimeSector(Wx, y, h);

	computeError(m, dt, aeroForce, h);
	//���������� ������� ������. ������� ���� ������ = Pi/6
	double spec_alpha = M_PI / 6;
	double spec_speed_x = startSpeed * cos(spec_alpha);
	double spec_speed_z = startSpeed * sin(spec_alpha);
	std::thread t1(computeCoordinatesEulerMethod, m, dt, Wx, aeroForce, spec_speed_x, y, time, std::ref(x_speed), std::ref(x));
	std::thread t2(computeCoordinatesEulerMethod, m, dt, Wz, aeroForce, spec_speed_z, y, time, std::ref(z_speed), std::ref(z));
	t1.join();
	t2.join();

	t1 = std::thread(replacePath, std::ref(x), x[x.size() - 1]);
	t2 = std::thread(replacePath, std::ref(z), z[z.size() - 1]);
	t1.join();
	t2.join();
	std::ofstream out;
	out.open("trajectory.txt");
	if (out.is_open())
	{
		for (int i = 0; i < sizeOfcoordinates; i++) {
			out << dt * i << ' ' << sqrt(x_speed[i] * x_speed[i] + y_speed[i] * y_speed[i] + z_speed[i] * z_speed[i]) << ' ' << x[i] << ' ' << z[i] << ' ' << y[i] << std::endl;
		}
	}
	out.close();
	x_speed.clear();
	z_speed.clear();
	x.clear();
	z.clear();
	unsigned int end_time1 = clock();
	float search_time = end_time1 - start_time;
	std::cout << "Computations complete. See file \"trajectory.txt\"" << std::endl;
	std::cout << "Computations completed with time: " << search_time/1000<<" sec" << std::endl;
	std::cout << "Computing trajectories in all cases..." << std::endl;
	start_time = clock();
	double alpha = 0;
	double dfi = 2 * M_PI / 360;
	std::vector<std::pair<double, double>>  dischargeCoordinates;
	for (int i = 0; i < 90; i++) {

		alpha = alpha + 2 * M_PI / 90;
		double speed1 = startSpeed * cos(alpha);
		double speed2 = startSpeed * sin(alpha);
		t1 = std::thread(computeCoordinatesEulerMethod, m, dt, Wx, aeroForce, speed1, y, time, std::ref(x_speed), std::ref(x));
		t2 = std::thread(computeCoordinatesEulerMethod, m, dt, Wz, aeroForce, speed2, y, time, std::ref(z_speed), std::ref(z));
		t1.join();
		t2.join();
		x_speed.clear();
		z_speed.clear();
		t1 = std::thread(replacePath, std::ref(x), x[x.size() - 1]);
		t2 = std::thread(replacePath, std::ref(z), z[z.size() - 1]);
		t1.join();
		t2.join();
		dischargeCoordinates.push_back(std::pair<double, double>(x[0], z[0]));
		x.clear();
		z.clear();
	}
	out.open("discharge_coordinates.txt");
	if (out.is_open())
	{
		for (int i = 0; i < dischargeCoordinates.size(); i++) {
			out << dischargeCoordinates[i].first << ' ' << dischargeCoordinates[i].second << std::endl;
		}
	}
	out.close();
	int end_time = clock();
	search_time = end_time - start_time;
	std::cout << "Computations complete. See file \"discharge_coordinates.txt\"" << std::endl;
	std::cout << "Computations completed with time: " << search_time/1000 <<" sec"<< std::endl;
	system("pause");
	return 0;
}