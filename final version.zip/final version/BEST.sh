#!/bin/bash
echo "Hello world!"
g++ -lm -o output main.cpp
./output
./trajectory.py
